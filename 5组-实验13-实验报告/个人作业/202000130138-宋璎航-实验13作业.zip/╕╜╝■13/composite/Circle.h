#ifndef _CIRCLE_H
#define _CIRCLE_H

#include "Point.h"
#include "Line.h"
#include <iostream>
using namespace std;

class Circle
{
public:
    Circle(const Point &o, float r)
    {
        this->o = o;
        this->r = r;
    }
    void show()
    {
        cout << "Circle with the center in o:(" << o.getX() << "," << o.getY() << "), the radius is " << r << endl;
    }

private:
    Point o;
    float r;
};


#endif