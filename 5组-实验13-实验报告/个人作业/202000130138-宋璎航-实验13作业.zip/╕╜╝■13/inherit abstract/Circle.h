#ifndef _CIRCLE_H
#define _CIRCLE_H

#include "Point.h"
#include "Shape.h"
#include <iostream>
using namespace std;

class Circle: public Shape
{
public:
    Circle (const Point &o, float r)
    {
        this->o = o;
        this->r = r;
    }

    virtual void show()
    {
        cout << "Circle with the center in o:(" << o.getX() << "," << o.getY() << "), the radius is " << r << endl;
    }
private:
    Point o;
    float r;
};

#endif